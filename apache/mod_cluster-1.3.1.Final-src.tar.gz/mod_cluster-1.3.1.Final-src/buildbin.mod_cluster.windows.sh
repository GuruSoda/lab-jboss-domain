#!/bin/sh
# Copyright(c) 2008 Red Hat Middleware, LLC,
# and individual contributors as indicated by the @authors tag.
# See the copyright.txt in the distribution for a
# full listing of individual contributors.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library in the file COPYING.LIB;
# if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
#
# @author Jean-Frederic Clere
# @author Mladen Turk
#
echo ""
echo "Running : `basename $0` $LastChangedDate: 2014-11-28 10:22:39 -0500 (Fri, 28 Nov 2014) $"
echo ""
echo "Started : `date`"
echo "Common  : $1"
echo "Prefix  : $2"
echo "Output  : $3"
echo "OpenSSL : $4"
echo "Static  : $5"
echo "Sources : $6"
echo ""


# parameters
# $1: Location of the common libraries.
# $2: Destination location.
# $3: Location where to put the binaries.
# $4: Use OpenSSL.
# $5: Use static build.
# $6: Location of the sources.

common_loc=$1
prefix_loc=$2
output_loc=$3
has_openssl=$4
has_static=$5
sources_loc=$6
current_loc=`pwd`

win_common_loc=`cygpath -w -a ${common_loc}`
win_prefix_loc=`cygpath -w -a ${prefix_loc}`

echo "Configuring Httpd"
add_conf="PREFIX=${win_prefix_loc}"
if $has_openssl ; then
  add_conf="${add_conf} WITH_OPENSSL=${win_common_loc}"
fi

case ${httpd_version} in
  2.2*)
    dirhttpd=httpd-2.2
    ;;
  2.4*)
    dirhttpd=httpd-2.4
    ;;
esac
mkdir -p ${output_loc}/${dirhttpd}
win_output_loc=`cygpath -w -a ${output_loc}/${dirhttpd}`

native_sources=srclib/`ls srclib | grep ${dirhttpd}`
src_dir=`cygpath -w -a ${native_sources}` 

(cd $native_sources
 echo "Running nmake at `pwd`"
 echo "nmake -f NMAKEmakefile PREFIX=${win_output_loc} ${add_conf} all and install"
 echo "nmake -f NMAKEmakefile PREFIX=${win_output_loc} ${add_conf} all" > make.bat
 nmake -f NMAKEmakefile PREFIX=${win_output_loc} ${add_conf} all || exit 1
 echo "nmake -f NMAKEmakefile PREFIX=${win_output_loc} ${add_conf} install" >> make.bat
 nmake -f NMAKEmakefile PREFIX=${win_output_loc} ${add_conf} install || exit 1
) || exit 1

# Also build the java part.
# It is not working on dev16 so we ignore the error for the moment.
mod_cluster_sources=srclib/`ls srclib | grep mod_cluster`
echo "JAVA_HOME: ${JAVA_HOME}"
echo "MVN_HOME: ${MVN_HOME}"
PATH="$JAVA_HOME"/bin:$MVN_HOME/bin:$PATH
export PATH
echo $PATH
java -version
(cd ${mod_cluster_sources} || exit 1
  mvn -P dist install -Djava.awt.headless=true -Djboss.server.log.dir=`pwd` -Djava.net.preferIPv4Stack=true
  if [ $? -ne 0 ]; then
    echo "mvn -P dist install -Djava.awt.headless=true -Djboss.server.log.dir=`pwd` -Djava.net.preferIPv4Stack=true FAILED"
    exit 1
  fi
  mvn -P dist package -Djava.awt.headless=true -Djboss.server.log.dir=`pwd` -Djava.net.preferIPv4Stack=true -Dmaven.test.skip=true
  if [ $? -ne 0 ]; then
    echo "mvn -P dist package -Djava.awt.headless=true -Djboss.server.log.dir=`pwd` -Djava.net.preferIPv4Stack=true FAILED"
    exit 1
  fi
  cp target/*-bin.* ${build_top}/output
) || exit 1

# copy the openssl libraries.
if $has_openssl ; then
  echo "cp ${win_common_loc}/bin/*.dll ${win_output_loc}/bin/"
  cp ${win_common_loc}/bin/libeay32.dll ${win_output_loc}/bin/
  cp ${win_common_loc}/bin/ssleay32.dll ${win_output_loc}/bin/
fi

# Add default mod_cluster conf in httpd.conf
case $build_version in
  1.0.*|1.1.*|1.2.*)
    slotmem=slotmem
    ;;
  1.3.*)
    slotmem=cluster_slotmem
    ;;
esac
case $build_version in
  1.0.*)
    ;;
  1.1.*|1.2.*|1.3.*)
    case ${httpd_version} in
      2.2*)
        cat >> "${win_output_loc}/conf/default/httpd.conf.in" <<EOF

LoadModule proxy_module modules/mod_proxy.so
LoadModule proxy_ajp_module modules/mod_proxy_ajp.so
LoadModule proxy_http_module modules/mod_proxy_http.so

LoadModule proxy_cluster_module modules/mod_proxy_cluster.so

LoadModule manager_module modules/mod_manager.so
LoadModule ${slotmem}_module modules/mod_${slotmem}.so
LoadModule advertise_module modules/mod_advertise.so

# MOD_CLUSTER_ADDS
# Adjust to you hostname and subnet.
<IfModule manager_module>
  Listen @@MCMPIP@@:@@MCMPPORT@@
  ManagerBalancerName mycluster
  <VirtualHost @@MCMPIP@@:@@MCMPPORT@@>
    <Location />
     Order deny,allow
     Deny from all
     Allow from @@SUBIP@@
    </Location>

    KeepAliveTimeout 300
    MaxKeepAliveRequests 0
    #ServerAdvertise on http://@@MCMPIP@@:@@MCMPPORT@@
    AdvertiseFrequency 5
    #AdvertiseSecurityKey secret
    #AdvertiseGroup @@ADVIP@@:23364
    EnableMCPMReceive

    <Location /mod_cluster_manager>
       SetHandler mod_cluster-manager
       Order deny,allow
       Deny from all
       Allow from 127.0.0
    </Location>

  </VirtualHost>
</IfModule>
EOF
        ;;
      2.4*)
        cat >> "${win_output_loc}/conf/default/httpd.conf.in" <<EOF

LoadModule proxy_module modules/mod_proxy.so
LoadModule proxy_ajp_module modules/mod_proxy_ajp.so
LoadModule proxy_http_module modules/mod_proxy_http.so

LoadModule proxy_cluster_module modules/mod_proxy_cluster.so

LoadModule manager_module modules/mod_manager.so
LoadModule ${slotmem}_module modules/mod_${slotmem}.so
LoadModule advertise_module modules/mod_advertise.so

# MOD_CLUSTER_ADDS
# Adjust to you hostname and subnet.
<IfModule manager_module>
  Listen @@MCMPIP@@:@@MCMPPORT@@
  ManagerBalancerName mycluster
  <VirtualHost @@MCMPIP@@:@@MCMPPORT@@>
    <Location />
     Require ip @@SUBIP@@
    </Location>

    KeepAliveTimeout 300
    MaxKeepAliveRequests 0
    #ServerAdvertise on http://@@MCMPIP@@:@@MCMPPORT@@
    AdvertiseFrequency 5
    #AdvertiseSecurityKey secret
    #AdvertiseGroup @@ADVIP@@:23364
    EnableMCPMReceive

    <Location /mod_cluster_manager>
       SetHandler mod_cluster-manager
       Require ip 127.0.0
    </Location>

  </VirtualHost>
</IfModule>
EOF
        ;;
    esac
    cp -p "${win_output_loc}\bin\installconf.bat" "${win_output_loc}\bin\installconf.$$"
    sed "s:8080:8000:" "${win_output_loc}\bin\installconf.bat" > "${win_output_loc}\bin\installconf.$$"
    mv "${win_output_loc}\bin\installconf.$$" "${win_output_loc}\bin\installconf.bat"
    ;;
esac

echo "Done"
exit 0
