#!/bin/sh
# Copyright(c) 2008 Red Hat Middleware, LLC,
# and individual contributors as indicated by the @authors tag.
# See the copyright.txt in the distribution for a
# full listing of individual contributors.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library in the file COPYING.LIB;
# if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
#
# @author Jean-Frederic Clere
#
echo ""
echo "Running : `basename $0` $LastChangedDate: 2015-05-07 12:21:37 -0400 (Thu, 07 May 2015) $"
echo ""
echo "Started : `date`"
echo "Tag     : $1"
echo "Target  : $2"
echo "Destdir : $3"
echo "HttpVer : $4"
echo ""

# parameters
# $1: The tag to use something like 2.2.6 or trunk
# $2: Directory where to put the sources.

tag=$1
dist=$2
destdir=$3
httpd_version=$4

# we need something like:
# http://anonsvn.jboss.org/repos/mod_cluster/trunk/
# https://github.com/modcluster/mod_cluster/tarball/mod-cluster-1.0.6.GA
if [  $USE_GIT ]; then
  echo "Using GIT!!!"
  case $tag in
    master)
      URLBASE=http://github.com/modcluster/mod_cluster/tarball/master
      ;;
    *.org)
      URLBASE=http://github.com/jfclere/mod_cluster/tarball/${tag}
      ;;
    *)
      URLBASE=http://github.com/modcluster/mod_cluster/tarball/${tag}
      #URLBASE=http://github.com/jfclere/mod_cluster/tarball/${tag}
      #URLBASE=http://github.com/rhusar/mod_cluster/tarball/${tag}
      #URLBASE=http://github.com/Karm/mod_cluster/tarball/${tag}
      ;;
  esac
else
  case $tag in
    trunk)
      URLBASE=http://anonsvn.jboss.org/repos/mod_cluster/trunk/
      ;;
    branches/*)
      URLBASE=http://anonsvn.jboss.org/repos/mod_cluster/${tag}/
      ;;
    *)
      URLBASE=http://anonsvn.jboss.org/repos/mod_cluster/tags/${tag}
      ;;
  esac
fi

echo "$tag using $URLBASE"

(cd $package_src_dir/srclib
if [ $USE_GIT ]; then
  wget --no-check-certificate ${URLBASE}
  mv $tag $tag.gz
  gzip -dc $tag.gz | $gnutar xvf -
  mod_cluster_dir=`ls | grep "\-mod_cluster"`
  mv ${mod_cluster_dir} mod_cluster
else
  svn export ${URLBASE} mod_cluster
fi
)
if [ $? -ne 0 ]; then
  echo "checkout of ${URLBASE} mod_cluster FAILED"
  exit 1
fi

if [ ! -d $package_src_dir/srclib/mod_cluster ]; then
  echo "$package_src_dir/srclib/mod_cluster not found!"
  echo "checkout ${URLBASE} mod_cluster FAILED"
  exit 1
fi

# Check the version in native/include/mod_proxy_cluster.h
grep MOD_CLUSTER_EXPOSED_VERSION $package_src_dir/srclib/mod_cluster/native/include/mod_proxy_cluster.h | grep $build_version
if [ $? -ne 0 ]; then
  echo "Can't find $build_version in $package_src_dir/srclib/mod_cluster/native/include/mod_proxy_cluster.h"
  exit 1
fi

#
# Copy the files to httpd src.
mkdir -p ${destdir}/modules/advertise
mkdir -p ${destdir}/modules/mod_manager
if [ -d $package_src_dir/srclib/mod_cluster/native/mod_cluster_slotmem ]; then
  mkdir -p ${destdir}/modules/mod_cluster_slotmem
  cp -p $package_src_dir/srclib/mod_cluster/native/mod_cluster_slotmem/* ${destdir}/modules/mod_cluster_slotmem
else
  mkdir -p ${destdir}/modules/mod_slotmem
  cp -p $package_src_dir/srclib/mod_cluster/native/mod_slotmem/* ${destdir}/modules/mod_slotmem
fi
cp -p $package_src_dir/srclib/mod_cluster/native/advertise/* ${destdir}/modules/advertise
cp -p $package_src_dir/srclib/mod_cluster/native/mod_manager/* ${destdir}/modules/mod_manager

cp -p $package_src_dir/srclib/mod_cluster/native/include/* ${destdir}/modules/proxy
cp -p $package_src_dir/srclib/mod_cluster/native/mod_proxy_cluster/mod_proxy_cluster.c ${destdir}/modules/proxy
cp -p $package_src_dir/srclib/mod_cluster/native/mod_proxy_cluster/*.patch ${destdir}/modules/proxy

# Fix the config.m4 to build mod_cluster
case ${httpd_version} in
  2.2*)
   configm4patch=config.m4.patch
   ;;
  2.4*)
   configm4patch=config.m4.2.4.patch
   ;;
esac
echo "$patch ${configm4patch} in ${destdir}/modules/proxy"
(cd ${destdir}/modules/proxy
 $patch -p0 < ${configm4patch}
)
